import { Schema, model } from "mongoose";
const carSchema = new Schema({
  model: {
    type: String,
    required: [true, "Model is required"],
    minLength: [2, "Model must be at least 2 characters long"],
  },
  manufacturer: {
    type: String,
    required: [true, "Manufacturer is required"],
    minLength: [3, "Manufacturer must be at least 3 characters long"],
  },
  engine: {
    type: String,
    required: [true, "Engine is required"],
    minLength: [3, "Engine must be at least 3 characters long"],
  },
  topSpeed: {
    type: Number,
    required: [true, "Top Speed is required"],
    min: [10, "Top Speed must be at least 2 digit number"],
  },
  image: {
    type: String,
    required: [true, "ImageUrl is required"],
    validate: [/^https?:\/\//, "ImageUrl must be a valid URL"],
  },
  description: {
    type: String,
    required: [true, "Description is required"],
    minLength: [5, "Description must be at least 5 characters long"],
    maxLength: [500, "Description must be at most 500 characters long"],
  },
  owner: {
    type: Schema.Types.ObjectId,
    ref: "User",
  },
  likes: [
    {
      type: Schema.Types.ObjectId,
      ref: "User",
    },
  ],
});

const Car = model('Car', carSchema)
export default Car