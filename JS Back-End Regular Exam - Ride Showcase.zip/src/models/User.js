import { Schema, model } from "mongoose";
import bcypt from "bcrypt"
const userSchema = new Schema({
  firstName: {
    type: String,
    required: [true, "firstName is required"],
    minLength: [3, "First name must be at least 3 characters long"],
  },
  lastName: {
    type: String,
    required: [true, "lastName is required"],
    minLength: [3, "Last name must be at least 3 characters long"],
  },
  email: {
    type: String,
    required: [true, "Email is required"],
    unique: true,
    minLength: [10, "Email must be at least 10 characters long"],
  },
  password: {
    type: String,
    required: [true, "Password is required"],
    minLength: [4, "Password must be at least 4 characters long"],
  },
});//Hashing password before saving
userSchema.pre("save", async function () {
    this.password =await bcypt.hash(this.password, 10)
})
const User = model('User', userSchema)
export default User