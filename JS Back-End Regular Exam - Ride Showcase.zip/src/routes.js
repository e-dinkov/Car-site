import { Router } from "express";
import homeController from "./controllers/homeController.js";
import userController from "./controllers/userController.js";
import carController from "./controllers/carController.js";

const routes = Router();
routes.use(homeController);
routes.use("/users", userController);
routes.use("/cars",carController)
routes.all("*url", (req, res) => res.render("home/404"));
export default routes;