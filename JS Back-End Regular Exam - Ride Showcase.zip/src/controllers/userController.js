import { Router } from "express";
import userService from "../services/userService.js";
import { isAuth, isGuest } from "../middlewares/authMiddleware.js";
import { getErrorMessage } from "../utils/errorUtli.js";
const userController = Router();

userController.get("/register",isGuest, (req, res) => {
    res.render("user/register", {pageTitle:"Register"});
    
});
userController.post("/register",isGuest, async(req, res) => {
    //console.log(req.body);
    const userData = req.body
    try {
        await userService.register(userData)
        const token = await userService.login(userData);
        res.cookie("auth", token);
        res.redirect("/");
    
    } catch (error) {
       res.render("user/register", { error: getErrorMessage(error),userData})
    }
    
})
userController.get("/login",isGuest, (req, res) => {
    res.render("user/login", { pageTitle: "Login" });
})
userController.post("/login",isGuest, async (req, res) => {
    const loginData = req.body
    //console.log(loginData);
    
    try {
        const token = await userService.login(loginData)
        res.cookie("auth", token)
        res.redirect("/")
    } catch (error) {
        res.render("user/login", { error: getErrorMessage(error), loginData })
    }
    
    
})
userController.get("/logout",isAuth, (req, res) => {
    res.clearCookie("auth")
    res.redirect("/")
})
export default userController;