import { Router } from "express";
import { isAuth } from "../middlewares/authMiddleware.js";
import { getErrorMessage } from "../utils/errorUtli.js";
import carService from "../services/carService.js";
import userService from "../services/userService.js";
const carController = Router();

carController.get("/create",isAuth, (req, res) => {
    res.render("car/create", {pageTitle:"Create"});
    
});
carController.post("/create",isAuth, async(req, res) => {
    //console.log(req.body);
    const carData = req.body
    const ownerId = req.user._id
    try {
        await carService.createCar(carData, ownerId)
        res.redirect("/cars")
    } catch (error) {
        res.render("car/create", { error: getErrorMessage(error),carData})
    }
    
})
carController.get("/", async(req, res) => {
    const cars = await carService.getAll()
    res.render("car/all-posts", {pageTitle:"Browse",cars});
    
});
carController.get("/my",isAuth, async(req, res) => {
    const ownerId = req.user._id
    try {
       const cars = await carService.getAllByOwner(ownerId)
    res.render("car/my-posts", {pageTitle:"My Cars",cars}); 
    } catch (error) {
        res.render("home/404", { error: getErrorMessage(error)})
    }

    
    
});
carController.get("/:id/details", async(req, res) => {
    const carId = req.params.id
    try {
         const car = await carService.getById(carId)
    const user = await userService.getById(car.owner)
    const isOwner = car.owner == req.user?._id;
    
    const isLiked = car.likes.includes(req.user?._id)
    const likesCount = car.likes.length
    let likers = await Promise.all(car.likes.map(id => userService.getById(id)))
    likers = likers.map(e => e.email).join(", ")
    //console.log(likers);
    
    
    
    //const allLikes = await carService.getAllLikes(carId)
    res.render("car/details", {pageTitle:"Details",car,user,isOwner,isLiked,likesCount,likers});
    } catch (error) {
        res.render("home/404", { error: getErrorMessage(error)})
    }
   
    
});
carController.get("/:id/like",isAuth, async(req, res) => {
    const carId = req.params.id
    const userId = req.user._id
    try {
        const car = await carService.getById(carId);
    const isOwner = car.owner == req.user?._id
    const isLiked = car.likes.includes(req.user?._id);
    if(isLiked) {
        throw new Error("You have already liked this car")
    }
    if(isOwner) {
        throw new Error("Cannot like your own car")
    }
    await carService.like(carId, userId)
    res.redirect(`/cars/${carId}/details`)
    } catch (error) {
        res.render("home/404", { error: getErrorMessage(error)})
    }
    
    
});
carController.get("/:id/delete",isAuth, async(req, res) => {
    const carId = req.params.id
    const userId = req.user._id
    try {
       const car = await carService.getById(carId)
    const isOwner = car.owner == req.user?._id
    if(!isOwner) {
        throw new Error("You cannot delete this car")
    }
    await carService.delete(carId)
    res.redirect("/cars")  
    } catch (error) {
        res.render("home/404", { error: getErrorMessage(error)})
    }
   
    
});

carController.get("/:id/edit",isAuth, async(req, res) => {
    const carId = req.params.id
    const userId = req.user._id
    try {
       const carData = await carService.getById(carId)
    const isOwner = carData.owner == req.user?._id
    if(!isOwner) {
        throw new Error("You cannot edit this car")
    }
    res.render("car/edit", {pageTitle:"Edit",carData})  
    } catch (error) {
        res.render("home/404", { error: getErrorMessage(error)})
    }
})
carController.post("/:id/edit",isAuth, async(req, res) => {
    const carId = req.params.id
    const carData = req.body
    const userId = req.user._id
    try {
       const carForCheck = await carService.getById(carId)
    const isOwner = carForCheck.owner == req.user?._id
    if(!isOwner) {
        return res.render("home/404", { error: "You cannot edit this car" });
        }
        console.log(carId,carData);
        
    await carService.edit(carId, carData)
    res.redirect(`/cars/${carId}/details`)  
    } catch (error) {
        res.render("car/edit", { error: getErrorMessage(error),carData})
    }
})
export default carController;