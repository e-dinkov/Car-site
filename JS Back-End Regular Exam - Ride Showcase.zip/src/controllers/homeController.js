import { Router } from "express";
import { getErrorMessage } from "../utils/errorUtli.js";
const homeController = Router();
getErrorMessage

homeController.get("/", (req, res) => {
    res.render("home",{pageTitle:"Home"});
    
});
export default homeController;