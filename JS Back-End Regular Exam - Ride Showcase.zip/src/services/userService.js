
import User from "../models/User.js"
import bcrypt from "bcrypt"
import jsonwebtoken from "jsonwebtoken"
import { get } from "mongoose"
export default {
    async register(userData) {
        const { firstName, lastName, email, password, rePassword } = userData
        //check if passwords are the same
        if(userData.password !== userData.rePassword) {
            throw new Error("Passwords do not match")
        }
        //Check if user exists
        const existingUser = User.countDocuments({ email: userData.email })
        if(existingUser > 0) {
            throw new Error("User already exists")
        }
        return User.create({ firstName, lastName, email, password })
    },
    async login(userData) {
        const { email, password } = userData
        const user = await User.findOne({ email })
        if(!user) {
            throw new Error("User does not exist")
        }
       // console.log(user.password,password);
        
        const isValidPassword = await bcrypt.compare(password, user.password)
        if(!isValidPassword) {
            throw new Error("Invalid password")
        }
        const payload = {
            _id: user._id,
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName
           
        }
        const token = jsonwebtoken.sign(payload, "-049u3jtq$@#QT#^$@%@eqw", { expiresIn: "2h" })
        return token

    },
    getById(id) {
        return User.findById(id)
    }
}