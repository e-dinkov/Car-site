import { get } from "mongoose";
import Car from "../models/Car.js";
export default {
    createCar(carData, ownerId) {
       return Car.create({ ...carData, owner: ownerId })
    },
    getAll() {
        return Car.find({})
    },
    getAllByOwner(ownerId) {
        return Car.find({owner: ownerId})
    },
    getById(id) {
        return Car.findById(id)
    },
    async like(carId, userId) {
        const car = await Car.findById(carId)
        car.likes.push(userId)
        return car.save()
    },
     delete(carId) {
        return Car.findByIdAndDelete(carId)
    },
     edit(carId, carData) {
        return Car.findByIdAndUpdate(carId, carData, {runValidators: true})
    }
}