import mongoose from "mongoose";
async function intitDb() {
 const dbUrl = "mongodb://localhost:27017";
const dbName = "examSkeletDb";
try {
    await mongoose.connect(dbUrl, { dbName });   
    console.log("Database connected");
} catch (error) {
    console.log("Database connection failed");
    console.log(error.message);
    
}

}
export default intitDb
