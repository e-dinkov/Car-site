import jsonwebtoken from "jsonwebtoken"
export function auth(req, res, next) {
    const token = req.cookies["auth"];
    if (!token) {
        return next()
    }
    try {
        const payload = jsonwebtoken.verify(token, "-049u3jtq$@#QT#^$@%@eqw")
        req.user = payload
        res.isAuthenticated = true
        res.locals.user = payload
        res.locals.isAuthenticated = true
        next()
    } catch (error) {
        console.log(error);
        res.clearCookie("auth")
        res.redirect("/users/login")
    }
    
}
export function isAuth(req, res, next) {
    if (!res.isAuthenticated) {
        return res.redirect("/users/login")
        
    }
    next()
}
export function isGuest(req, res, next) {
    if (res.isAuthenticated) {
        return res.redirect("/")
    }
    next()
}